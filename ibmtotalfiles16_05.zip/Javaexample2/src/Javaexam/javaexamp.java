package Javaexam;

public class javaexamp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(ConcatMethod("Harish","HS"));
	}
public static String ConcatMethod (String Fname, String Lname) {
    return "Mr. " + Fname + " " + Lname;	
}


}