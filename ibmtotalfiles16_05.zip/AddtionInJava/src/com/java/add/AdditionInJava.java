package com.java.add;

public class AdditionInJava {
	
	public static int addInJava(int a,int b) {
		return a+b;
		
		
	}

}
