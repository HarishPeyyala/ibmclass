package JAVArevstr;

public class JAVAreversestr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(concatMethod("HARSIH", "PEYYALA"));
		System.out.println(reverseStr("HARISH"));
	}

	public static String concatMethod(String FName, String LName) {
		return "Mr. " + FName + " " + LName;
	}

	public static String reverseStr(String Name) {

		StringBuffer sbr = new StringBuffer(Name);
		sbr.reverse();
		return sbr.toString();

	}
}