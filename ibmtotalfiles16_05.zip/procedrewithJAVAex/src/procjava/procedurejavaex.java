package procjava;

public class procedurejavaex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println(concatMethod("Harish", "P"));
    System.out.println(reverseStr("naresh"));
    
		
	}
	public static String concatMethod(String FName, String LName) {
       return "Mr. " + FName + " " + LName;
}

	
	public static String reverseStr(String Name){
		
		// String str = "Geeks";
		 
	        // conversion from String object to StringBuffer
	        StringBuffer sbr = new StringBuffer(Name);
	        // To reverse the string
	        sbr.reverse();
	        //System.out.println(sbr);
		return sbr.toString();

	}
}